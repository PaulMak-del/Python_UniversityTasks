def dec(num):
    return num - 1

