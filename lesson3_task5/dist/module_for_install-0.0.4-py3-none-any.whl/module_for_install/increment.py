def inc(num):
    return num + 1
