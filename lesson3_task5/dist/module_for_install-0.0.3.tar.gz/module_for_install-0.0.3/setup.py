import setuptools

setuptools.setup(
    name='module_for_install',
    version='0.0.3',
    author='Pavel Khomenko',
    author_email='your@domain.com',
    description='My Package for university task',
    packages=setuptools.find_packages(),
)
