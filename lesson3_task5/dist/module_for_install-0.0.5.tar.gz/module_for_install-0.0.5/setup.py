import setuptools

setuptools.setup(
    name='module_for_install',
    version='0.0.5',
    author='Pavel Khomenko',
    author_email='your@domain.com',
    description='My Package for university task',
    packages=setuptools.find_packages(),
    include_package_data=True
)
